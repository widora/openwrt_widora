#include <stdint.h>

#define fixed32         int32_t
#define fixed64         int64_t

